# STULKER
# Good evening, we are from Ukraine!

Funny 3d TPS (but it may will be RPG - I don't definite it yet) game based on S.T.A.L.K.E.R. game series.
I'm creating the game with open source applications:
- game engine - Godot Engine
- 3D modeling - Blender3D of course!
- textures and art - GIMP, Krita, Pixelorama(https://orama-interactive.itch.io/pixelorama)
- sounds & music - Audacity, Ardour, LMMS

modified!